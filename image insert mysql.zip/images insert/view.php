

<!DOCTYPE html>
<html>

<head>  
<style>
#content{
	margin-left:30%;
	margin-right:30%;
	width:40%;
}
#content,img{
	
	width:100px;
}
</style>


</head>
<body>



<div id="content">
<?php
$db = mysqli_connect("localhost", "root", "", "photos");
$sql ="SELECT * FROM images";
$result = mysqli_query($db,$sql);
while($row = mysqli_fetch_array($result)){
	echo"<div>";
	echo "<table>";
	
	echo "<tr>";
	
	echo"<td><img src='images/".$row['image']."'></td>";
	echo"<td><p>".$row['text']."</p></td>";
	echo "</tr>";
	echo "</table>";
	echo"</div>";
}




?>
</div>
</body>
</html>