<!DOCTYPE html>
<html>
<body>

<?php
$msg = "";

if(isset($_POST["upload"])) {

$target = "images/".basename($_FILES['image']['name']);

$db = mysqli_connect("localhost", "root", "", "photos");
 
 
 $image = $_FILES['image']['name'];
 $text = $_POST['text'];
 
 
 $sql =" INSERT INTO images (image,text) VALUES ('$image' , '$text' )";
   
   mysqli_query($db, $sql);
    if(move_uploaded_file($_FILES['image']['tmp_name'] ,$target)){
	
    $msg ="image upload sucessfuly";
	
	}else{
		$msg ="THere was aproblem uploading image";
	
	}
	
	
}
?>




<div id="content">





<form action="index.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    
<input type="file" name="image" >
 
<input type="text" name="text" >
  <input type="submit" value="Upload Image" name="upload">
</form>
</div>
</body>
</html>